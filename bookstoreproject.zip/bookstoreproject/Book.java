//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 4
//Submission Time: 5:30
package bookstoreproject;

public class Book  implements Comparable<Book> { //assining variables
    private String title;
    private String author;
    private int edition;
    private double price;
    
public Book(String title, String author, int edition, double price) //constructor
    {
        this.title = title;
        this.author = author;
        this.edition = edition;
        this.price = price;
    }
public String getInfo() //format of the books
    {
        return String.format("%-15s%-15s%-10d%-10f", title.substring(0,10), author.substring(0,10), edition, price);   
    }

@Override
public int compareTo(Book other) //comparing the books
{
    return title.compareTo(other.title);
}

}

//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 4
//Submission Time: 5:30
package bookstoreproject;

import java.util.ArrayList;
import java.util.Collections;

public class BookStore
{
    private String address;
    private String name;
    private ArrayList<Book> books = new ArrayList<>();

    public BookStore(String address, String name) //constructor
    {
    this.address = address;
    this.name = name;
    }
            
public void addBook (Book book) //adds books
    {
        books.add(book);
    }

public void sortBooks()
    {
    Collections.sort(books);
    }

public void listBooks() //returns format
    {
       System.out.println("Title          Author      Edition       Price ");
        System.out.println("-----------------------------------------------------"); 
       
        
    for (Book t : books)
        { 
        System.out.println(t.getInfo());
        }
    System.out.println("-----------------------------------------------------"); 
    }
}

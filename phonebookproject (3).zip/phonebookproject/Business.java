//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 5
//Submission Time: 5:30
package phonebookproject;


public class Business extends Contact 
{
    private int Zip;
    
    public Business (String name, long phone, int Zip) //constructor
    {
        super (name, phone);
        this.Zip = Zip;
    }
    
    @Override
    public String getInfo() //prints info
    {
         return super.getInfo() + String.format("%-15d", Zip);    
    }
}



    
    

//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 5
//Submission Time: 5:30
package phonebookproject;

import java.util.ArrayList;
import java.util.Collections;

public class PhonebookProject 
{
   
    public static void main(String[] args) //main
    {
        Phonebook myPhoneBook = new Phonebook();
        
        myPhoneBook.addBusiness("WalMart", 22566647, 70809);
        myPhoneBook.addBusiness("Chick-fil-a", 22533448, 70808);
        myPhoneBook.addBusiness("Alpha Mechanic", 22566789, 70813);
        
        myPhoneBook.addPerson("Luke Skywalker", 22500111, "Brother");
        myPhoneBook.addPerson("Darth Vader", 22500122, "Father");
        myPhoneBook.addPerson("Princess Lia", 22500133, "Sister");
        
        myPhoneBook.printContacts();
    }
    
}

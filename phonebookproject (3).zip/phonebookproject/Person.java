//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 5
//Submission Time: 5:30
package phonebookproject;


public class Person extends Contact 
{
    private String relationship;

    public Person(String name, long phone, String relationship) //constructor
    {
        super(name,phone);
        this.relationship = relationship;
    }

    @Override
    public String getInfo()  //prints info
    {
         return super.getInfo() + String.format("%-15s", relationship);    
    }
}
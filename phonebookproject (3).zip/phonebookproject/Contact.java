//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 5
//Submission Time: 5:30
package phonebookproject;

public class Contact implements Comparable<Contact>
{
    private String name;
    private long phone;

public Contact(String name, long phone) //constructor
    {
     this.name = name;
     this.phone = phone;
    }

public String getInfo() //prints info
{
    return String.format("%-20s%-20d", name, phone);
}

@Override
public int compareTo(Contact other) //compares
{
return name.compareTo(other.name);
}

}
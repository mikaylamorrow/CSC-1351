//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 5
//Submission Time: 5:30
package phonebookproject;

import java.util.ArrayList;
import java.util.Collections;

public class Phonebook //array list
{
    private ArrayList<Person> person = new ArrayList<>();
    private ArrayList<Business> business = new ArrayList<>();
    
    public void addPerson(String name, long phone, String relationship) //adds person
    {
        person.add(new Person(name, phone, relationship));
    }

    public void addBusiness(String name, long phone, int Zip) //adds business
    {
        business.add(new Business(name, phone, Zip));
    }
    public void printContacts() //prints out statments
    {
      Collections.sort(person);   
      Collections.sort(business);
      
      System.out.println("Person name         Phone               Relationship ");
      System.out.println("-----------------------------------------------------"); 
      for (Person t : person)
        { 
        System.out.println(t.getInfo());
        }
      
      System.out.println("-----------------------------------------------------");
      System.out.println("Business name       Phone               Zip");
      System.out.println("-----------------------------------------------------"); 
      for (Business t : business)
        { 
        System.out.println(t.getInfo());
        }
    }


}

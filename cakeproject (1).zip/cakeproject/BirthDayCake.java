//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 3
//Submission Time: 5:00
package cakeproject;

public class BirthDayCake extends Cake //inhearites the parents class Cake
{
    private String firstName;
    private int age;
    
    public BirthDayCake(String flavor, int tiers, double price, String firstName, int age)
    {
    super(flavor, tiers, price);
    this.firstName = firstName;
    this.age = age;
    }
    
    @Override
    public void printCard() //prints out statement on to cake card
    {
        System.out.println("Happy Birthday to " + firstName + "! You just turned " + age + ":)");
    }
}

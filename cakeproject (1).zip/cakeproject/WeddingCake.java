//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 3
//Submission Time: 5:00
package cakeproject;

public class WeddingCake extends Cake //inhearites the parents class Cake
{       
    private String bridesFirstName;
    private String groomsFirstName;
    
    public WeddingCake (String flavor, int tiers, double price, String brideName, String groomName)
    {
        super (flavor, tiers, price);
        this.bridesFirstName = brideName;
        this.groomsFirstName = groomName;   
    }
    @Override
    public void printCard() //prints out statement on to cake card
    {
        System.out.println("Happy Wedding to " + bridesFirstName + " and " + groomsFirstName + "!");
        super.printCard();   
    }
    
}

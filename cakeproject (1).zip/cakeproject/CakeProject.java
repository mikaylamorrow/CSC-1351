//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 3
//Submission Time: 5:00
package cakeproject;

public class CakeProject {
   
    public static void main(String[] args) //Prints out each cake card
    {
      
        WeddingCake WedCk = new WeddingCake("chocolate", 3, 355.0, "Sarah", "John");
        WedCk.printInvoice();
        WedCk.printCard();
        
        System.out.println("---------------------------------------------------");

        BirthDayCake bdCk = new BirthDayCake ("vanilla", 1 , 20.0, "Alan", 15);
        bdCk.printInvoice();
        bdCk.printCard();

    }
        
}

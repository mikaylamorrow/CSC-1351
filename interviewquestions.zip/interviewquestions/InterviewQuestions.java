//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 9
//Submission Time: 5:00

package interviewquestions;

import java.util.*;

public class InterviewQuestions 
{

    
    public static void main(String[] args) 
    {
        System.out.println(isPalindrome("Racecar"));
        System.out.println(isPalindrome("steve"));
        System.out.println(isBalancedExpression("{}{}({()})") );
        System.out.println(isBalancedExpression("((){}{}") );
        System.out.println(evaluateExpression("42+351-*+"));
        System.out.println(evaluateExpression("545*+5/"));   
    }
        
    public static boolean isPalindrome(String input)
    {
        char[] chars = input.toCharArray();
        Stack<Character> myStack = new Stack<>();
        
            for(int a=0; a<chars.length;a++)
                myStack.push(chars[a]);
                String reverse = "";

            for(int a=0; a<chars.length;a++)
                    reverse += myStack.pop();
            
            if(input.equalsIgnoreCase(reverse))
                return true;
        
        return false;
    }
    public static boolean isBalancedExpression(String expression)
    {
        char[] chars = expression.toCharArray();
        Stack<Character> myStack = new Stack<>();
        
        for(int a=0; a<chars.length;a++)
        {
            if(chars[a] == '(' || chars[a] == '{')
                myStack.push(chars[a]);
                else if (chars[a] == ')' || chars[a] =='}')
                {
                    char op = myStack.pop();

                    if((op == '(' && chars[a] != ')')||(op == '{' && chars[a] != '}'))
                    return false;
                }
        }
        if (myStack.size()== 0)
            return true;
        
        return false;
    }
    
    public static int evaluateExpression(String expression)
    {
        char[] chars = expression.toCharArray();
        Stack<Integer> myStack = new Stack<>();
        
        for(int a=0; a<chars.length;a++)
        {
            if(Character.isDigit(chars[a]))
                myStack.push(Character.getNumericValue(chars[a]));
            else if (chars[a] == '+' || chars[a] =='-' || chars[a] == '*' || chars[a] == '/')
            {
                int num1 = myStack.pop();
                int num2 = myStack.pop();
                
                if (chars[a] == '+')
                    myStack.push(num2 + num1);
                if (chars[a] == '-')
                    myStack.push(num2 - num1);
                if (chars[a] == '*')
                    myStack.push(num2 * num1);
                if (chars[a] == '/')
                    myStack.push(num2 / num1);
            }
        }
        return myStack.pop();
    }
    
}

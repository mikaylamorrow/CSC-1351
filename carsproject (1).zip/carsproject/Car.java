//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 2
//Submission Time: 6:00

package carsproject;


public class Car 
{
    private long vin;
    public String modle;
    public int year;
    public double mileage;

    public void setMileage(double Mileage) 
    {
        mileage = Mileage;
    }

    public Car()
    {
    }

    public Car(long Vin,  int Year, String Modle)
    {
      vin = Vin; 
      modle = Modle;
      year = Year;    
    }


    public String getInfo() 
    {
       return year + " " + modle + " (VIN: " + vin +", mileage: " + mileage + " miles)";   
    }

}
    


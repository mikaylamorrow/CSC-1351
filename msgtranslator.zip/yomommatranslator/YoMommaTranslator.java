//Student Name: Mikayla Morrow
//LSU ID: 895224693
//Lab Section: 1
//Assignment: Lab 8
//Submission Time: 5:30

package yomommatranslator;

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
        
public class YoMommaTranslator 
{
    public static void main(String[] args) throws FileNotFoundException 
    {
    
       Map<String,String> words = new TreeMap<>();  
               
       File input = new File ("acronyms.txt");
       Scanner inn = new Scanner(input);
       String line;
       
       while(inn.hasNextLine())
       {
            line = inn.nextLine();
            String[] splitted = line.split("\\t");
            words.put(splitted[0],splitted[1]);
       }
   
        System.out.println("Enter A Sentence: ");

        Scanner in = new Scanner(System.in).useDelimiter("\\n");
        String userInput = in.next().toUpperCase();
        String[] split = userInput.split("\\s+");
        
        
        String exp = "";
        
       for(int a=0; a<split.length; a++)
       {
           if(words.containsKey(split[a]))
               exp += words.get(split[a]) + " ";
           else
               exp += split[a].toLowerCase() + " "; 
       }
       
        System.out.println(exp);
       
    }  
}
